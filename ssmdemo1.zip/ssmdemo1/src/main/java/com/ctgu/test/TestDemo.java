package com.ctgu.test;

import com.ctgu.dao.TbAuthorMapper;
import com.ctgu.pojo.TbAuthor;
import com.ctgu.service.TbAuthorService;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author Alin
 * @packagename com.ctgu.test
 * @date 2019/8/2
 * @time 9:19
 */

public class TestDemo {

//    @Test
//    public void testService() {
//        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
//        TbAuthorService tbAuthorService = (TbAuthorService) context.getBean("tbAuthorService");
//        tbAuthorService.happy();
//    }

//    @Test
//    public void testDao() {
//        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
//        TbAuthorMapper tbAuthorMapper = (TbAuthorMapper) context.getBean("tbAuthorMapper");
//        TbAuthor tbAuthor = tbAuthorMapper.selectByPrimaryKey(1);
//        System.out.println(tbAuthor);
//    }

}
